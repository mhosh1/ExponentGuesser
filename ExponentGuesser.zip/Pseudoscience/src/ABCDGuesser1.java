import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class ABCDGuesser1 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private ABCDGuesser1() {
    }

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {

        double number = 0; // initializing the number variable as 0.
        while (number <= 0) { /*
                               * the loop continues looping until a positive
                               * number is entered
                               */
            out.print("what constant μ should be approximated that is a "
                    + "positive real number: ");
            String usersNumber = in.nextLine();
            if (FormatChecker
                    .canParseDouble(usersNumber)) { /*
                                                     * Check if the input can be
                                                     * parsed as a double
                                                     */
                number = Double.parseDouble(
                        usersNumber); /*
                                       * Convert the input to a double.
                                       */
            } else {
                out.println("This is not a correct input value.");
            }
        }
        return number; // Return the positive real number entered by the user.

    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in,
            SimpleWriter out) {

        double number = 0; // // initializing the number variable as 0.
        while (number <= 0
                || number == 1.0) { /*
                                     * the loop continues looping until a
                                     * positive number that is greater than o
                                     * and not equal to one is entered
                                     */
            out.print("Enter a positive real number not equal to 1.0: ");
            String usersNumber = in.nextLine();
            if (FormatChecker
                    .canParseDouble(usersNumber)) { /*
                                                     * Check if the input can be
                                                     * parsed as a double
                                                     */
                number = Double.parseDouble(
                        usersNumber); /*
                                       * Convert the input to a double.
                                       */
            } else { // telling the user that the input is invalid.
                out.println("This is not a correct input value.");
            }
        }
        return number; // Return the positive real number entered by the user.
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments The main method reads input from
     *            the user and performs calculations to find the best
     *            approximation for a given set of exponents.
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        //Get a positive real number from the user for mu.
        double mu = getPositiveDouble(in, out);
        // Getting a positive real number that is not equal to 1.0 for w,x,y,z
        double w = getPositiveDoubleNotOne(in, out);
        double x = getPositiveDoubleNotOne(in, out);
        double y = getPositiveDoubleNotOne(in, out);
        double z = getPositiveDoubleNotOne(in, out);

        // Making an array of exponents.
        final double[] exponents = { -5, -4, -3, -2, -1, -1.0 / 2, -1.0 / 3,
                -1.0 / 4, 0, 1.0 / 4, 1.0 / 3, 1.0 / 2, 1, 2, 3, 4, 5 };

        // Initialize the bestApproximation variable as the maximum double value.
        double bestApproximation = Double.MAX_VALUE;
        double bestA = 0;
        double bestB = 0;
        double bestC = 0;
        double bestD = 0;

        /*
         * The program uses a loop to iterate through different combinations of
         * exponents and calculates the approximation based on user-provided
         * value
         */
        int indexA = 0;
        while (indexA < exponents.length) {
            double a = exponents[indexA];

            int indexB = 0;
            while (indexB < exponents.length) {
                double b = exponents[indexB];

                int indexC = 0;
                while (indexC < exponents.length) {
                    double c = exponents[indexC];

                    int indexD = 0;
                    while (indexD < exponents.length) {
                        double d = exponents[indexD];

                        double approximation = Math.pow(w, a) * Math.pow(x, b)
                                * Math.pow(y, c) * Math.pow(z, d);
                        double difference = Math.abs(approximation - mu);

                        // It keeps track of the best approximation
                        if (difference < bestApproximation) {

                            bestApproximation = difference;
                            bestA = a;
                            bestB = b;
                            bestC = c;
                            bestD = d;
                        }

                        indexD++;
                    }

                    indexC++;
                }

                indexB++;
            }

            indexA++;

        }
        final double relativeError = Math
                .round((bestApproximation / mu) * 10000)
                / 100.0; /*
                          * Calculate the relative error as a percentage
                          */

        // Printing the results
        out.println("Exponents: a = " + bestA + ", b = " + bestB + ", c = "
                + bestC + ", d = " + bestD);
        out.println("Approximation: " + Math.pow(w, bestA) * Math.pow(x, bestB)
                * Math.pow(y, bestC) * Math.pow(z, bestD));
        out.println("Relative Error: " + relativeError + "%");

        in.close(); // Close the input stream
        out.close(); // Close the output stream.
    }

}
